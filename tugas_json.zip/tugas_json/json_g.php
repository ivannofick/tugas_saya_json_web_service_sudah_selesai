<?php
include 'conn/koneksi.php';
 $sql = "SELECT kategori from tbl_buku ";
 $query = mysql_query($sql);
 $rows=array();
 while($data = mysql_fetch_assoc($query)){
 $rows[] = $data;
 }
 echo json_encode($rows);
?>
