<?php 
	$db_host = "localhost";
	$db_user = "root";
	$db_pass = "root";
	$db_name = "bookstore";
	$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    	$sql = "Select isbn, judul, pengarang, penerbit, tahun, kategori, jumlah from tbl_buku";
	$query = mysqli_query($koneksi, $sql);
	$rows=array();
	while($data = mysqli_fetch_assoc($query)){
		$rows[] = $data;
	}
	echo json_encode($rows);
?>






