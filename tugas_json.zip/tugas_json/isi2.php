<?php 
	$db_host = "localhost";
	$db_user = "root";
	$db_pass = "root";
	$db_name = "bookstore";
	$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    	$sql = "Select isbn, judul, pengarang, penerbit, tahun, kategori, jumlah from tbl_buku
         join penerbit on id_penerbit = id_penerbit
         join pengarang on id_pengarang = id_pengarang";
	$query = mysqli_query($koneksi, $sql);
	$rows=array();
	while($data = mysqli_fetch_assoc($query)){
		$rows[] = $data;
	}
	echo json_encode($rows);
?>


<!--?php 
	$db_host = "localhost";
	$db_user = "root";
	$db_pass = "root";
	$db_name = "bookstore";
	$tok = $_GET["tok"];
	$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    	$sql = "Select isbn, judul, pengarang, penerbit, tahun, kategori, jumlah from tbl_buku where id_kategori='$tok'"; //iki seng salah
	$query = mysqli_query($koneksi, $sql);
	$rows=array();
	while($data = mysqli_fetch_assoc($query)){
		$rows[] = $data;
	}
	echo json_encode($rows);
?>











