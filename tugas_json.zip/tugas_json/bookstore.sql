-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 04, 2017 at 11:28 PM
-- Server version: 5.5.55-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bookstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(10) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Umum'),
(2, 'Agama'),
(3, 'Sosial'),
(4, 'Bahasa'),
(5, 'Teknologi');

-- --------------------------------------------------------

--
-- Table structure for table `penerbit`
--

CREATE TABLE IF NOT EXISTS `penerbit` (
  `id_penerbit` int(50) NOT NULL AUTO_INCREMENT,
  `nama_penerbit` varchar(100) NOT NULL,
  PRIMARY KEY (`id_penerbit`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `penerbit`
--

INSERT INTO `penerbit` (`id_penerbit`, `nama_penerbit`) VALUES
(1, 'Gramedia'),
(2, 'Andi Publisher'),
(3, 'Erlangga'),
(4, 'Mizan'),
(5, 'Replubika');

-- --------------------------------------------------------

--
-- Table structure for table `pengarang`
--

CREATE TABLE IF NOT EXISTS `pengarang` (
  `id_pengarang` int(50) NOT NULL AUTO_INCREMENT,
  `nama_pengarang` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pengarang`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pengarang`
--

INSERT INTO `pengarang` (`id_pengarang`, `nama_pengarang`) VALUES
(1, 'Pramoedya Ananta Toer'),
(2, 'Suwarsih Djojopuspito'),
(3, 'Taufiq Ismail'),
(4, 'Mochtar Lubis'),
(5, 'Ahmad Tohari');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_buku`
--

CREATE TABLE IF NOT EXISTS `tbl_buku` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `pengarang` varchar(150) NOT NULL,
  `id_pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(200) NOT NULL,
  `id_penerbit` int(50) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `isbn` varchar(50) NOT NULL,
  `kategori` varchar(70) NOT NULL,
  `id_kategori` int(10) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `masuk` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_buku`
--

INSERT INTO `tbl_buku` (`id`, `judul`, `pengarang`, `id_pengarang`, `penerbit`, `id_penerbit`, `tahun`, `isbn`, `kategori`, `id_kategori`, `jumlah`, `masuk`) VALUES
(1, 'Cinta Brontosaurus', 'Pramoedya Ananta Toer', '1', 'Gramedia', 1, '2016', '12345', 'Umum', 1, 5, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE IF NOT EXISTS `tbl_transaksi` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `nim` int(20) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `tgl_pinjam` varchar(15) NOT NULL,
  `tgl_kembali` varchar(15) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `nim` int(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `ttl` varchar(50) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `jk` enum('L','P') NOT NULL,
  `progdi` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `nim`, `nama`, `ttl`, `tempat_lahir`, `jk`, `progdi`, `alamat`, `username`, `password`, `email`, `level`) VALUES
(1, 0, '', '', '', '', 'Pilih Prodi', '', 'root', '63a9f0ea7b', '', ''),
(2, 98898, 'gandul', '18-april-1997', 'semarang', 'L', 'teknik informatika', 'genuk 03/03', 'gandol', 'admin', 'ivannofick@gmail.com', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
