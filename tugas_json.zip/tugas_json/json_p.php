<?php

	$json_data=file_get_contents("http://localhost/google_map/coba_harus/sudah/kategori.php");
	$obj = json_decode($json_data);

	$json_data2=file_get_contents("http://localhost/google_map/coba_harus/sudah/pengarang.php");
	$obj2 = json_decode($json_data2);

	$json_data3=file_get_contents("http://localhost/google_map/coba_harus/sudah/json_penerbit.php");
	$obj3 = json_decode($json_data3);
	//foreach($obj as $ob){
	//	echo $ob->kategori;
	//}
?>
