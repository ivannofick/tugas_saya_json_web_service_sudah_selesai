   <?php
   include 'conn/koneksi.php';
   ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Book Store</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Book Store</a>
            </div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Cetak <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Laporan</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Lihat <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Laporan</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="../logout.php">Logout</a>
                    </li>
</ul>
</div>
        </div>
        <!-- /.container -->
    </nav>
<div class="container">
 <div clas="row">
            <div class="col-lg-12">
                <h1 class="page-header">
			SELAMAT DATANG ADMIN
                </h1>
            </div>
</div>
 <table class="table table-bordered">
    <thead>
      <tr>
        <th style="text-align:center;">No</th>
        <th style="text-align:center;">Nama Buku</th>
        <th style="text-align:center;">Pengarang</th>
        <th style="text-align:center;">Penerbit</th>
        <th style="text-align:center;">Tahun</th>
        <th style="text-align:center;">Jumlah</th>
      </tr>
    </thead>
	<?php
		$query = "select*from tbl_buku ORDER by judul desc";
		$sql = mysql_query($query);
		$total = mysql_num_rows($sql);
		$no = 1;
		while ($data=mysql_fetch_array($sql)){

	?>
    <tbody>
      <tr>
        <td align="center"><?php echo $no; ?></td>
   	<td align="center"><?php echo $data['judul']; ?></td>
        <td align="center"><?php echo $data['pengarang']; ?></td>
        <td align="center"><?php echo $data['penerbit']; ?></td>
        <td align="center"><?php echo $data['tahun']; ?></td>
   	<td align="center"><?php echo $data['jumlah']; ?></td>
        <td align="center"><a href="?page=buku_edit&id=<?php echo $data['id']; ?>">Edit</a></td>
                <td align="center"><a href="?page=buku_hapus&id=<?php echo $data['id']; ?>" onclick="return confirm('Anda yakin ingin menghapus data buku <?php echo $data['judul']; ?> ?')">Hapus</a></td>
      </tr>
            <?php $no++; } ?>
    </tbody>
  </table>
        	<table class="table">
            	<tr>
                	<td width="50%">Jumlah : <?php echo $total; ?> buku</td>
                    
                </tr>
            </table>
</div>
<!--end-->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>

</html>

