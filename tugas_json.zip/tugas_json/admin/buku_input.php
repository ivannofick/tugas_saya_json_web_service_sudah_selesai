   <?php
   include 'conn/koneksi.php';
	$tanggal = date('Y-m-d');
	$jam = date('H:i:s');
	$waktu = $tanggal.' '.$jam;
   ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Book Store</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Book Store</a>
            </div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Cetak <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Laporan</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Lihat <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Laporan</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="../logout.php">Logout</a>
                    </li>
</ul>
</div>
        </div>
        <!-- /.container -->
    </nav>
<div class="container">
        <form action="buku_proses.php" method="post">
        <input type="hidden" name="masuk" value="<?php echo $waktu; ?>">
 <div clas="row">
            <div class="col-lg-12">
                <h1 class="page-header">
			TAMBAH DATA Buku
                </h1>
            </div>
</div>
	<div class="row">
		 <div class="col-md-2">
			Judul Buku
		 </div>
		 <div class="col-md-8">
			<input type="text" name="judul">
		 </div>
	</div>
<br>
	<div class="row">
		<div class="col-md-2">
			Pengarang
		</div>
		<div class="col-md-8">
			<input type="text" name="pengarang">
		</div>
	</div>
<!--END-->
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			ID Pengarang
		 </div>
		 <div class="col-md-8">
			<select name="id_pengarang">
                    		<option value="">Pilih Pengarang</option>
	                        <option value="1">Mochtar Lubis</option>
	                        <option value="2">Ahmad Tohari</option>
	                        <option value="3">Pramoedya Ananta Toer </option>
	                        <option value="4">Taufiq Ismail</option>
	                        <option value="5">Suwarsih Djojopuspito</option>
			</select>
		</div>
	</div>
<br>
	<div class="row">
		<div class="col-md-2">
			Penerbit
		 </div>
		 <div class="col-md-8">
			<input type="text" name="penerbit">
		</div>
	</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			ID Penerbit
		 </div>
		 <div class="col-md-8">
			<select name="id_penerbit">
                    		<option value="">Pilih Penerbit</option>
	                        <option value="1">GRAMEDIA</option>
	                        <option value="2">Mizan</option>
	                        <option value="3"> Agro Media Grup</option>
	                        <option value="4">Republika Penerbit</option>
	                        <option value="5">Tiga Serangkai Pustaka Mandiri</option>
	                        <option value="6">Erlangga</option>
	                        <option value="7">Andi Publisher </option>
	                        <option value="8">Diva Press Grup </option>
	                        <option value="9">Indiva Media Kreasi</option>
	                        <option value="10">Media Pressindo</option>
			</select>
		</div>
	</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			Tahun
 		</div>
 		<div class="col-md-8">
			<select name="tahun">
                    		<option value="">Pilih Tahun</option>
	                        <option value="2017">2017</option>
        	                <option value="2016">2016</option>
                	        <option value="2015">2015</option>
                        	<option value="2014">2014</option>
                            	<option value="2013">2013</option>
                            	<option value="2012">2012</option>
                            	<option value="2011">2011</option>
                            	<option value="2010">2010</option>
                            	<option value="2009">2009</option>
                            	<option value="2008">2008</option>
                            	<option value="2007">2007</option>
                            	<option value="2006">2006</option>
                            	<option value="2005">2005</option>
                            	<option value="2004">2004</option>
                            	<option value="2003">2003</option>
                            	<option value="2002">2002</option>
                            	<option value="2001">2001</option>
                            	<option value="2000">2000</option>
                            	<option value="1999">1999</option>
                            	<option value="1998">1998</option>
                            	<option value="1997">1997</option>
                            	<option value="1996">1996</option>
                            	<option value="1995">1995</option>
                            	<option value="1994">1994</option>
                            	<option value="1993">1993</option>
                            	<option value="1992">1992</option>
                            	<option value="1991">1991</option>
                            	<option value="1990">1990</option>
			</select>
 		</div>
</div>
<!--END-->
<br>
		<div class="row">
 			<div class="col-md-2">
				Isbn
			</div>
			<div class="col-md-8">
				<input type="text" name="isbn">
			</div>
		</div>
<!--END-->
<br>
		<div class="row">
			<div class="col-md-2">
				Kategori
			</div>
			<div class="col-md-8">
			<select name="kategori">
                    		<option value="">Pilih</option>
	                        <option value="Umum">Umum</option>
	                        <option value="Filsafat dan Psikologi">Filsafat dan Psikologi</option>
	                        <option value="Agama">Agama</option>
	                        <option value="Sosial">Sosial </option>
	                        <option value="Bahasa">Bahasa</option>
	                        <option value="Sains dan Matematika">Sains dan Matematika</option>
	                        <option value="Teknologi">Teknologi</option>
	                        <option value="Seni dan Rekreasi">Seni dan Rekreasi</option>
	                        <option value="Literartur dan Sastra">Literartur dan Sastra</option>
	                        <option value="Sejarah dan Geografi">Sejarah dan Geografi</option>
			</select>
			</div>
		</div>
<!--END-->
<br>
		<div class="row">
			<div class="col-md-2">
				Id Kategori
			</div>
			<div class="col-md-8">
				<select name="id_kategori">
                    		<option value="">Pilih</option>
	                        <option value="1">Umum</option>
	                        <option value="2">Filsafat dan Psikologi</option>
	                        <option value="3">Agama</option>
	                        <option value="4">Sosial </option>
	                        <option value="5">Bahasa</option>
	                        <option value="6">Sains dan Matematika</option>
	                        <option value="7">Teknologi</option>
	                        <option value="8">Seni dan Rekreasi  </option>
	                        <option value="9">Literartur dan Sastra </option>
	                        <option value="10">Sejarah dan Geografi</option>
			</select>
			</div>
		</div>
<!--END-->
</br>
		<div class="row">
			<div class="col-md-2">
				Jumlah
			</div>
			<div class="col-md-8">
				<input type="text" name="jumlah">
			</div>
		</div>
<!--END-->
</br>
		<div class="row">
			<div class="col-md-4">
				<input type="submit" class="btn btn-info" value="simpan">
 			</div>
		</div>
</from>
<!--END-->
</div>
<!--end-->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>

</html>

