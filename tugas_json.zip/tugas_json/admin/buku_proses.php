<?php
include 'conn/koneksi.php';

$judul = $_POST ['judul'];
$pengarang = $_POST['pengarang'];
$id_pengarang = $_POST['id_pengarang'];
$penerbit = $_POST['penerbit'];
$id_penerbit = $_POST['id_penerbit'];
$tahun = $_POST['tahun'];
$isbn	= $_POST['isbn'];
$kategori = $_POST['kategori'];
$id_kategori = $_POST['id_kategori'];
$jumlah = $_POST['jumlah'];
$tgl_input = $_POST['masuk'];
		

 $input = mysql_query("INSERT into tbl_buku values('','$judul', '$pengarang', '$id_pengarang', '$penerbit', '$id_penerbit', '$tahun', '$isbn', '$kategori', '$id_kategori', '$jumlah', '$tgl_input')");
 
if ($input) {
	echo "<script> alert('Data berhasil Ditambahkan') </script>";
	echo "<meta http-equiv='refresh' content='0; url=buku_input.php'>";	
}
else {
	echo "<script> alert('Data Gagal Di Input') </script>";
	echo "<meta http-equiv='refresh' content='0; url=buku_input.php'>";	
}

?>
