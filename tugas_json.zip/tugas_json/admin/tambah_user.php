   <?php
   include 'conn/koneksi.php';
	$tanggal = date('Y-m-d');
	$jam = date('H:i:s');
	$waktu = $tanggal.' '.$jam;
   ?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Book Store</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/modern-business.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Book Store</a>
            </div>
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Input <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Cetak <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Laporan</a>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Lihat <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                    	    <li>
                                <a href="buku_tambah.php">Buku</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Anggota</a>
                            </li>
                            <li>
                                <a href="tambah_user.php">Laporan</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="../logout.php">Logout</a>
                    </li>
</ul>
</div>
        </div>
        <!-- /.container -->
    </nav>
<div class="container">
        <form action="angota_proses.php" method="post">
        <input type="hidden" name="masuk" value="<?php echo $waktu; ?>">
 <div clas="row">
            <div class="col-lg-12">
                <h1 class="page-header">
			TAMBAH DATA USER
                </h1>
            </div>
</div>
	<div class="row">
		 <div class="col-md-2">
			Nim
		 </div>
		 <div class="col-md-8">
			<input type="text" name="nim">
		 </div>
	</div>
<br>
	<div class="row">
		<div class="col-md-2">
			Nama
		</div>
		<div class="col-md-8">
			<input type="text" name="nama">
		</div>
	</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			Tempat Lahir
 		</div>
		<div class="col-md-8">
			<input type="text" name="tempat_lahir">

		</div>
 		
</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			Tanggal Lahir
 		</div>
		<div class="col-md-8">
			<input type="text" name="ttl">

		</div>
 		
</div>
<!--END-->
<br>
		<div class="row">
 			<div class="col-md-2">
				Jenis Kelamin
			</div>
			<div class="col-md-8">
				<input type="radio" name="jk" value="L"/>Laki-laki
   					<input type="radio" name="jk" value="P"/>Perempuan
			</div>
		</div>
<!--END-->
<br>
		<div class="row">
			<div class="col-md-2">
				Progdi
			</div>
			<div class="col-md-8">
				<select name="progdi">
                    		<option>Pilih Prodi</option>
                            <option value="Sistem Informasi">Sistem Informasi</option>
                            <option value="Komputer Akuntansi">Komputer Akuntansi</option>
                            <option value="Managemen">Managemen</option>
                    	</select>
			</div>
		</div>
<!--END-->
<br>
		<div class="row">
			<div class="col-md-2">
				Alamat
			</div>
			<div class="col-md-8">
				<input type="text" name="alamat">
			</div>
		</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			Username
 		</div>
		<div class="col-md-8">
			<input type="text" name="username">

		</div>
 		
</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			Password
 		</div>
		<div class="col-md-8">
			<input type="password" name="password">

		</div>
 		
</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			Email
 		</div>
		<div class="col-md-8">
			<input type="text" name="email">

		</div>
 		
</div>
<!--END-->
<br>
	<div class="row">
		<div class="col-md-2">
			Grup
 		</div>
		<div class="col-md-8">
			<select name="level">
                    		<option>Pilih User</option>
                            <option value="admin">Administrator</option>
                            <option value="user">User</option>                    
                    	</select>
		</div>
 		
</div>
<!--END-->
</br>
		<div class="row">
			<div class="col-md-4">
				<input type="submit" class="btn btn-info" value="simpen">
 			</div>
		</div>
</from>
<!--END-->
</div>
<!--end-->
    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
</body>

</html>

