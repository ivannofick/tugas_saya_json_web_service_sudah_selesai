<?php
include 'conn/koneksi.php';

$id= $_GET['id'];
$query = mysql_query("DELETE FROM tbl_buku WHERE id='$id'");
if ($query) {
		echo "<script>alert('Data berhasil dihapus')</script>";
		echo "<meta http-equiv='refresh' content='0; url=index.php'>";
	} else {
		echo "Data anda gagal dihapus. Ulangi sekali lagi";
		echo "<meta http-equiv='refresh' content='0; url=index.php'>";
	}


?>
