<?php
include 'conn/koneksi.php';

$nim = $_POST ['nim'];
$nama = $_POST['nama'];
$tempat_lahir = $_POST['tempat_lahir'];
$tgl_lahir = $_POST['ttl'];
$jk	= $_POST['jk'];
$progdi = $_POST['progdi'];
$alamat = $_POST['alamat'];
$user = mysql_real_escape_string($_POST['username']);
$pass = mysql_real_escape_string($_POST['password']);
$pass = md5($pass); 
$email = $_POST['email'];
$level = $_POST['level'];


 $input = mysql_query("INSERT into tbl_user values('', '$nim','$nama','$tempat_lahir','$ttl','$jk','$progdi','$alamat', '$user', '$pass', '$email', '$level')");
 
if ($input) {
	echo "<script> alert('Data berhasil Ditambahkan') </script>";
	echo "<meta http-equiv='refresh' content='0; url=tambah_user.php'>";	
}
else {
	echo "<script> alert('Data Gagal Di Input') </script>";
	echo "<meta http-equiv='refresh' content='0; url=tambah_user.php'>";
}

?>
